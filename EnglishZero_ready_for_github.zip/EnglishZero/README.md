# English Zero

PWA privada para aprender inglés desde cero con ruta de lecciones, XP, racha, cuaderno y mentor IA.

## Publicar en Vercel
Sube estos archivos al repositorio y pulsa Deploy en Vercel.
